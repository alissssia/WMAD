<%-- 
    Document   : category
    Created on : Mar 8, 2026, 2:57:30 PM
    Author     : entel
--%>

<%@ page import="entity.Category" %>
<%@ page import="entity.Product" %>
<%@ page import="java.util.List" %>
<%@ page import="cart.ShoppingCart" %>
<%@ page import="entity.AppUser" %>

<%
List<Category> categories = (List<Category>) request.getAttribute("categories");
List<Product> products = (List<Product>) request.getAttribute("products");
%>

<%@page contentType="text/html" pageEncoding="windows-1252"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <title>eCommerce Sample</title>
    </head>
    <body>
    </body>
</html>

<%
AppUser user = (AppUser) session.getAttribute("user");
%>

<p>
<%
if (user != null) {
%>
    Welcome, <%= user.getName() %> |
    <a href="<%=request.getContextPath()%>/history.do">Purchase history</a> |
    <a href="<%=request.getContextPath()%>/logout.do">Logout</a>
<%
} else {
%>
    <a href="<%=request.getContextPath()%>/view/login.jsp">Login</a> |
    <a href="<%=request.getContextPath()%>/view/register.jsp">Register</a>
<%
}
%>
</p>

<%
ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
int numItems = (cart != null) ? cart.getNumberOfItems() : 0;
%>

<p>
    <img src="<%=request.getContextPath()%>/img/cart.gif" alt="cart">
    <%= numItems %> items |
    <a href="<%=request.getContextPath()%>/viewcart.do">View cart</a>
</p>


<table width="70%" border="1" cellspacing="0" cellpadding="5">
    <tr>
        
        <!-- Columna izquierda: categor�as -->
        <td width="20%" valign="top">
            <table width="100%" border="1" cellspacing="0" cellpadding="3">
                <%
                if (categories != null) {
                    for (Category category : categories) {
                %>
                <tr>
                    <td align="center">
                        <a href="<%=request.getContextPath()%>/category.do?categoryid=<%=category.getId()%>">
                            <%=category.getName()%>
                        </a>
                    </td>
                </tr>
                <%
                    }
                }
                %>
            </table>
        </td>

        <!-- Columna derecha: productos -->
        <td width="80%" valign="top">
            <%
            if (products != null && !products.isEmpty()) {
            %>
            <table width="100%" border="1" cellspacing="0" cellpadding="5">
                <tr>
                    <th>product</th>
                    <th>name</th>
                    <th>price</th>
                    <th>stock</th>
                    <th>buy</th>
                </tr>
                <%
                for (Product product : products) {
                %>
                <tr>
                    <td width="25%" align="center">
                        <img src="<%=request.getContextPath()%>/img/products/<%=product.getName()%>.png"
                             alt="<%=product.getName()%>"
                             width="100">
                    </td>

                    <td width="25%" align="center">
                        <b><%=product.getName()%></b>
                        <br>
                        <%=product.getDescription()%>
                    </td>

                    <td width="25%" align="center">
                        <%=product.getPrice()%> �
                    </td>
                    
                    <td align="center" width="15%">
            <%=product.getStock()%>
                    </td>

                    <td align="center" width="25%">
                        <%
                        if (product.getStock() > 0) {
                        %>
                            <form action="<%=request.getContextPath()%>/neworder.do" method="post">
                                <input type="hidden" name="productId" value="<%=product.getId()%>">
                                <input type="hidden" name="categoryid" value="<%=request.getAttribute("currentCat")%>">
                                <input type="submit" value="add to cart">
                            </form>
                        <%
                        } else {
                        %>
                            Out of stock
                        <%
                        }
                        %>
                    </td>
                </tr>
                <%
                }
                %>
            </table>
            <%
            } else {
            %>
                No products found for this category.
            <%
            }
            %>
        </td>
    </tr>
    
</table>