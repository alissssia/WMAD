<%-- 
    Document   : cart
    Created on : Mar 18, 2026, 5:24:54 PM
    Author     : entel
--%>

<%@ page import="cart.ShoppingCart" %>
<%@ page import="entity.Product" %>
<%@ page import="java.util.List" %>
<%@ page import="java.text.DecimalFormat" %>
<%@ page import="cart.ShoppingCartItem" %>
<%@ page import="entity.AppUser" %>

<%
DecimalFormat df = new DecimalFormat("0.00");
HttpSession ses = request.getSession();
ShoppingCart cart = (ShoppingCart) ses.getAttribute("cart");
Integer lastCategoryId = (Integer) ses.getAttribute("lastCategoryId");
Boolean showPaypal = (Boolean) request.getAttribute("showPaypal");
if (showPaypal == null) {
    showPaypal = false;
}

String baseURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();

int numItems = 0;
double total = 0.0;
List<ShoppingCartItem> items = null;

if (cart != null && cart.getItems() != null && !cart.getItems().isEmpty()) {
    numItems = cart.getNumberOfItems();
    total = cart.getTotal();
    items = cart.getItems();
}
%>

<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <title>eCommerce Sample</title>
</head>
<body>

<h1>Your shopping cart</h1>

<%
AppUser user = (AppUser) session.getAttribute("user");
%>

<p>
<%
if (user != null) {
%>
    Welcome, <%= user.getName() %> |
    <a href="<%=request.getContextPath()%>/history.do">Purchase history</a> |
    <a href="<%=request.getContextPath()%>/logout.do">Logout</a>
<%
} else {
%>
    <a href="<%=request.getContextPath()%>/view/login.jsp">Login</a> |
    <a href="<%=request.getContextPath()%>/view/register.jsp">Register</a>
<%
}
%>
</p>

<%
if (items == null || items.isEmpty()) {
%>
    <p>Your cart is empty</p>
    <p>
        <a href="<%=request.getContextPath()%>/init.do">Continue shopping</a>
    </p>
<%
} else {
%>

<p>
    <img src="<%=request.getContextPath()%>/img/cart.gif" alt="cart">
    <%= numItems %> items
</p>

<h2>Your shopping cart contains <%= numItems %> items.</h2>

<p>
    <a href="<%=request.getContextPath()%>/clearcart.do">Clear cart</a>
</p>

<p>
    <a href="<%=request.getContextPath()%>/category.do?categoryid=<%=lastCategoryId%>">Continue shopping</a>
</p>

<%
if (!showPaypal) {
%>
    <p>
        <a href="<%=request.getContextPath()%>/checkout.do">Proceed to checkout</a>
    </p>
<%
} else {
%>

<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="business" value="wmad.alicia.emanuela@gmail.com">
    <input type="hidden" name="item_name" value="Total Amount">
    <input type="hidden" name="currency_code" value="EUR">
    <input type="hidden" name="amount" value="<%= String.format(java.util.Locale.US, "%.2f", cart.getTotal()) %>">
    <input type="hidden" name="return" value="<%=baseURL%>/purchase.do">
    <input type="hidden" name="cancel_return" value="<%=baseURL%>/purchase.do">

    <input type="image"
           src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif"
           border="0"
           name="submit"
           alt="PayPal - The safer, easier way to pay online!">

    <img alt=""
         border="0"
         src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif"
         width="1"
         height="1">
</form>
<%
}
%>

<table width="70%" border="1" cellspacing="0" cellpadding="5">
    <tr>
        <th>product</th>
        <th>name</th>
        <th>price</th>
        <th>quantity</th>
    </tr>

<%
    for (ShoppingCartItem item : items) {
        Product p = item.getProduct();
%>
    <tr>
        <td align="center" width="25%">
            <img src="<%=request.getContextPath()%>/img/products/<%=p.getName()%>.png"
                 alt="<%=p.getName()%>"
                 width="100">
        </td>

        <td align="center" width="25%">
            <b><%=p.getName()%></b>
            <br>
            <%=p.getDescription()%>
        </td>

        <td align="center" width="25%">
            <%= df.format(p.getPrice()) %> &euro;/unit
        </td>

        <td align="center" width="25%">
            <form action="<%=request.getContextPath()%>/updatecart.do" method="post">
                <input type="hidden" name="productid" value="<%=p.getId()%>">
                <input type="text" name="quantity" value="<%=item.getAmount()%>" size="3">
                <input type="submit" value="update">
            </form>
        </td>
    </tr>
<%
    }
%>

</table>

<p>
    <b>Total amount: <%= df.format(total) %> &euro;</b>
</p>

<%
}
%>

</body>
</html>
