<%@ page import="java.util.List" %>
<%@ page import="entity.PurchaseOrder" %>
<%@ page import="entity.PurchaseItem" %>
<%@ page import="java.text.DecimalFormat" %>

<%-- 
    Document   : history
    Created on : Apr 7, 2026, 11:16:06 PM
    Author     : entel
--%>

<%
DecimalFormat df = new DecimalFormat("0.00");
List<PurchaseOrder> orders = (List<PurchaseOrder>) request.getAttribute("orders");
model.PurchaseModel purchaseModel = (model.PurchaseModel) application.getAttribute("purchaseModel");
%>

<html>
<head>
    <title>Purchase History</title>
</head>
<body>

<h2>Purchase History</h2>

<p>
    <a href="<%=request.getContextPath()%>/init.do">Back to home</a>
</p>

<hr>

<%
if (orders == null || orders.isEmpty()) {
%>
    <p>No purchases found.</p>
<%
} else {
    for (PurchaseOrder order : orders) {
%>
        <h3>Order #<%= order.getId() %></h3>
        <p>Date: <%= order.getPurchaseDate() %></p>
        <p>Total: <%= df.format(order.getTotal()) %> &euro;/unit</p>

        <table border="1" cellspacing="0" cellpadding="5">
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Unit price</th>
            </tr>

            <%
            List<PurchaseItem> itemsHistory = purchaseModel.findItemsByOrder(order);
            for (PurchaseItem item : itemsHistory) {
            %>
            <tr>
                <td><%= item.getProduct().getName() %></td>
                <td><%= item.getQuantity() %></td>
                <td><%= df.format(item.getUnitPrice()) %> &euro;/unit</td>
            </tr>
            <%
            }
            %>
        </table>
        <br>
<%
    }
}
%>

</body>
</html>
