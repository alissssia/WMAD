<%-- 
    Document   : register
    Created on : Apr 7, 2026, 10:18:39 PM
    Author     : entel
--%>

<%@page contentType="text/html" pageEncoding="windows-1252"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <title>Register</title>
</head>
<body>

<h2>Register</h2>

<%
String error = (String) request.getAttribute("error");
if (error != null) {
%>
    <p style="color:red;"><%= error %></p>
<%
}
%>

<form action="<%=request.getContextPath()%>/register.do" method="post">
    <p>
        Name: <input type="text" name="name">
    </p>
    <p>
        Email: <input type="text" name="email">
    </p>
    <p>
        Password: <input type="password" name="password">
    </p>
    <p>
        <input type="submit" value="Register">
    </p>
</form>

<p>
    <a href="<%=request.getContextPath()%>/view/login.jsp">Already have an account? Login</a>
</p>

<p>
    <a href="<%=request.getContextPath()%>/init.do">Back to shop</a>
</p>

</body>
</html>