<%-- 
    Document   : login
    Created on : Apr 7, 2026, 10:19:27 PM
    Author     : entel
--%>

<%@page contentType="text/html" pageEncoding="windows-1252"%>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <title>Login</title>
</head>
<body>

<h2>Login</h2>

<%
String error = (String) request.getAttribute("error");
if (error != null) {
%>
    <p style="color:red;"><%= error %></p>
<%
}
%>

<form action="<%=request.getContextPath()%>/login.do" method="post">
    <p>
        Email: <input type="text" name="email">
    </p>
    <p>
        Password: <input type="password" name="password">
    </p>
    <p>
        <input type="submit" value="Login">
    </p>
</form>

<p>
    <a href="<%=request.getContextPath()%>/view/register.jsp">Create account</a>
</p>

<p>
    <a href="<%=request.getContextPath()%>/init.do">Back to shop</a>
</p>

</body>
</html>