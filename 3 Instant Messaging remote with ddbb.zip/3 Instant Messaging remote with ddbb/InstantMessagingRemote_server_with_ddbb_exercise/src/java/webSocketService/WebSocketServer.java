package webSocketService;

import com.google.gson.Gson;
import entity.Message;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import util.Subscription_request;
import util.Topic_check;
import entity.Topic;
import util.Subscription_close;
import entity.service.TopicFacadeREST;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

@ServerEndpoint("/ws")
public class WebSocketServer {

  TopicFacadeREST topicFacadeREST = lookupTopicFacadeRESTBean();

  // to store the open websocket sessions with the clients:
  private static Set<Session> sessions = new HashSet<Session>();
  
  // to store the subscriptions to the different topics of the connected clients:
  private static Map<Session, List<Topic>> subscriptions = new HashMap<Session, List<Topic>>();

  @OnMessage
  public void onMessage(String message, Session session)
    throws IOException, SQLException {

    System.out.println("onMessage: " + message);

    Subscription_request s_req =
        new Gson().fromJson(message, Subscription_request.class);

    Topic topic = s_req.topic;

    Topic_check check = topicFacadeREST.isTopic(topic);

    if (!check.isOpen) {
      return;
    }
    List<Topic> sessionSubscriptions = subscriptions.get(session);

    if (s_req.type == Subscription_request.Type.ADD) {

      if (!sessionSubscriptions.contains(topic)) {
        sessionSubscriptions.add(topic);
      }

    } else if (s_req.type == Subscription_request.Type.REMOVE) {

      sessionSubscriptions.remove(topic);
    }

  }

  @OnOpen
  public void onOpen(Session session) {
    sessions.add(session);
    subscriptions.put(session, new ArrayList<Topic>());
    System.out.println("new session: " + session.getId());
  }

  @OnClose
  public void onClose(Session session) {
    System.out.println("closed session: " + session.getId());
    sessions.remove(session);
    subscriptions.remove(session);
  }

  public static void notifyNewMessage(Message message) {

    String json_message = new Gson().toJson(message);
    Topic topic = message.getTopic();

    try {

      for (Session session : sessions) {

        List<Topic> sessionSubscriptions = subscriptions.get(session);

        if (sessionSubscriptions != null
            && sessionSubscriptions.contains(topic)
            && session.isOpen()) {

          session.getBasicRemote().sendText(json_message);
        }
      }

    } catch (Throwable e) {
      e.printStackTrace();
    }
  }

  public static void notifyTopicClose(Subscription_close subs_close) {

    Gson gson = new Gson();
    String json_subs_close = gson.toJson(subs_close);
    Topic topic = subs_close.topic;

    try {

      for (Session session : sessions) {

        List<Topic> sessionSubscriptions = subscriptions.get(session);

        if (sessionSubscriptions != null
            && sessionSubscriptions.contains(topic)
            && session.isOpen()) {

          session.getBasicRemote().sendText(json_subs_close);
          sessionSubscriptions.remove(topic);
        }
      }

    } catch (Throwable e) {
      e.printStackTrace();
    }
  }

  private TopicFacadeREST lookupTopicFacadeRESTBean() {
    try {
      Context c = new InitialContext();
      return (TopicFacadeREST) c.lookup("java:global/InstantMessagingRemote_server_with_ddbb_exercise/TopicFacadeREST!entity.service.TopicFacadeREST");
    } catch (NamingException ne) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", ne);
      throw new RuntimeException(ne);
    }
  }

}
