/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity.service;

import entity.Message;
import entity.Topic;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import webSocketService.WebSocketServer;

/**
 *
 * @author juanluis
 */
@Stateless
@Path("entity.message")
public class MessageFacadeREST extends AbstractFacade<Message> {

  @PersistenceContext(unitName = "PubSubWebServerPU")
  private EntityManager em;

  public MessageFacadeREST() {
    super(Message.class);
  }

  @POST
  @Path("create")
  @Consumes({"application/xml", "application/json"})
  public void create(Message entity) {
    
    Query query = em.createQuery(
      "SELECT t FROM Topic t WHERE t.name = :name");
    query.setParameter("name", entity.getTopic().getName());

    List<Topic> topics = query.getResultList();

    if (topics.isEmpty()) {
      return;
    }

    Topic topic = topics.get(0);

    Message messageToSave = new Message();
    messageToSave.setContent(entity.getContent());
    messageToSave.setTopic(topic);

    Message messageToSend = new Message();
    messageToSend.setContent(entity.getContent());
    messageToSend.setTopic(topic);

    super.create(messageToSave);

    WebSocketServer.notifyNewMessage(messageToSend);
    
  }

  @POST
  @Path("messagesFromTopic")
  @Consumes({"application/xml", "application/json"})
  @Produces({"application/xml", "application/json"})
  public List<Message> messagesFrom(Topic entity) {
    
    Query queryTopic = em.createQuery(
      "SELECT t FROM Topic t WHERE t.name = :name");
    queryTopic.setParameter("name", entity.getName());

    List<Topic> topics = queryTopic.getResultList();

    if (topics.isEmpty()) {
      return new java.util.ArrayList<Message>();
    }

    Topic topic = topics.get(0);

    Query queryMessages = em.createQuery(
        "SELECT m FROM Message m WHERE m.topic = :topic");
    queryMessages.setParameter("topic", topic);

    return queryMessages.getResultList();
    
  }

  @Override
  protected EntityManager getEntityManager() {
    return em;
  }

}
