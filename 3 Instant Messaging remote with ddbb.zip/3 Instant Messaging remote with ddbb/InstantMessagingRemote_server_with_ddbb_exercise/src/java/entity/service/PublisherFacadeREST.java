/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity.service;

import entity.Publisher;
import entity.Topic;
import util.Subscription_close;
import entity.User;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import webSocketService.WebSocketServer;

/**
 *
 * @author juanluis
 */
@Stateless
@Path("entity.publisher")
public class PublisherFacadeREST extends AbstractFacade<Publisher> {
  
  @PersistenceContext(unitName = "PubSubWebServerPU")
  private EntityManager em;

  public PublisherFacadeREST() {
    super(Publisher.class);
  }
  
  @POST
  @Path("create")
  @Consumes({"application/xml", "application/json"})
  @Produces({"application/xml", "application/json"})
  public void create(Publisher entity) {
    
    Query queryTopic = em.createQuery(
      "SELECT t FROM Topic t WHERE t.name = :name");
    queryTopic.setParameter("name", entity.getTopic().getName());

    List<Topic> topics = queryTopic.getResultList();

    Topic topic;

    if (topics.isEmpty()) {
      topic = new Topic();
      topic.setName(entity.getTopic().getName());
      em.persist(topic);
      em.flush();
    } else {
      topic = topics.get(0);
    }

    Query queryUser = em.createQuery(
        "SELECT u FROM User u WHERE u.login = :login");
    queryUser.setParameter("login", entity.getUser().getLogin());

    List<User> users = queryUser.getResultList();

    if (users.isEmpty()) {
      return;
    }

    User user = users.get(0);

    Query queryPublisher = em.createQuery(
        "SELECT p FROM Publisher p WHERE p.user = :user AND p.topic = :topic");
    queryPublisher.setParameter("user", user);
    queryPublisher.setParameter("topic", topic);

    List<Publisher> publishers = queryPublisher.getResultList();

    if (!publishers.isEmpty()) {
      return;
    }

    entity.setUser(user);
    entity.setTopic(topic);

    super.create(entity);
    
  }

  @POST
  @Path("delete")
  @Consumes({"application/xml", "application/json"})
  public void delete(Publisher entity) {
    
    Query queryUser = em.createQuery(
      "SELECT u FROM User u WHERE u.login = :login");
    queryUser.setParameter("login", entity.getUser().getLogin());

    List<User> users = queryUser.getResultList();

    if (users.isEmpty()) {
      return;
    }

    User user = users.get(0);

    Query queryTopic = em.createQuery(
        "SELECT t FROM Topic t WHERE t.name = :name");
    queryTopic.setParameter("name", entity.getTopic().getName());

    List<Topic> topics = queryTopic.getResultList();

    if (topics.isEmpty()) {
      return;
    }

    Topic topic = topics.get(0);

    Query queryPublisher = em.createQuery(
        "SELECT p FROM Publisher p WHERE p.user = :user AND p.topic = :topic");
    queryPublisher.setParameter("user", user);
    queryPublisher.setParameter("topic", topic);

    List<Publisher> publishers = queryPublisher.getResultList();

    if (publishers.isEmpty()) {
      return;
    }

    Publisher publisher = publishers.get(0);

    em.remove(em.merge(publisher));

    Query queryOtherPublishers = em.createQuery(
        "SELECT p FROM Publisher p WHERE p.topic = :topic");
    queryOtherPublishers.setParameter("topic", topic);

    List<Publisher> otherPublishers = queryOtherPublishers.getResultList();

    if (otherPublishers.isEmpty()) {

      Subscription_close close =
          new Subscription_close(topic, Subscription_close.Cause.PUBLISHER);

      WebSocketServer.notifyTopicClose(close);

      em.remove(em.merge(topic));
    }
    
    
  }
  
  @POST
  @Path("publisherOf")
  @Consumes({"application/xml", "application/json"})
  @Produces({"application/xml", "application/json"})
  public Publisher publisherOf(User entity) {  
    
    Query queryUser = em.createQuery(
      "SELECT u FROM User u WHERE u.login = :login");
    queryUser.setParameter("login", entity.getLogin());

    List<User> users = queryUser.getResultList();

    if (users.isEmpty()) {
      return null;
    }

    User user = users.get(0);

    Query queryPublisher = em.createQuery(
        "SELECT p FROM Publisher p WHERE p.user = :user");
    queryPublisher.setParameter("user", user);

    List<Publisher> publishers = queryPublisher.getResultList();

    if (publishers.isEmpty()) {
      return null;
    }

    return publishers.get(0);
    
  }
  
  @POST
    @Path("publishersOf")
    @Consumes({"application/xml", "application/json"})
    @Produces({"application/xml", "application/json"})
    public List<Publisher> publishersOf(User entity) {

      Query queryUser = em.createQuery(
          "SELECT u FROM User u WHERE u.login = :login");
      queryUser.setParameter("login", entity.getLogin());

      List<User> users = queryUser.getResultList();

      if (users.isEmpty()) {
        return new java.util.ArrayList<Publisher>();
      }

      User user = users.get(0);

      Query query = em.createQuery(
          "SELECT p FROM Publisher p WHERE p.user = :user");
      query.setParameter("user", user);

      return query.getResultList();
    }

  @Override
  protected EntityManager getEntityManager() {
    return em;
  }
  
}
