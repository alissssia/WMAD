/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity.service;

import entity.Subscriber;
import util.Subscription_check;
import util.Followers_check;
import entity.Topic;
import entity.User;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 *
 * @author upcnet
 */
@Stateless
@Path("entity.subscriber")
public class SubscriberFacadeREST extends AbstractFacade<Subscriber> {

  @PersistenceContext(unitName = "PubSubWebServerPU")
  private EntityManager em;

  public SubscriberFacadeREST() {
    super(Subscriber.class);
  }

  @POST
  @Path("create")
  @Consumes({"application/xml", "application/json"})
  @Produces({"application/xml", "application/json"})
  public Subscription_check check_to_create(Subscriber entity) {
    
    Query queryTopic = em.createQuery(
      "SELECT t FROM Topic t WHERE t.name = :name");
    queryTopic.setParameter("name", entity.getTopic().getName());

    List<Topic> topics = queryTopic.getResultList();

    if (topics.isEmpty()) {
      return new Subscription_check(entity.getTopic(),
          Subscription_check.Result.NO_TOPIC);
    }

    Topic topic = topics.get(0);

    Query queryUser = em.createQuery(
        "SELECT u FROM User u WHERE u.login = :login");
    queryUser.setParameter("login", entity.getUser().getLogin());

    List<User> users = queryUser.getResultList();

    if (users.isEmpty()) {
      return new Subscription_check(topic,
          Subscription_check.Result.NO_SUBSCRIPTION);
    }

    User user = users.get(0);

    Query querySubscription = em.createQuery(
        "SELECT s FROM Subscriber s WHERE s.topic = :topic AND s.user = :user");
    querySubscription.setParameter("topic", topic);
    querySubscription.setParameter("user", user);

    List<Subscriber> subscriptions = querySubscription.getResultList();

    if (!subscriptions.isEmpty()) {
      return new Subscription_check(topic,
          Subscription_check.Result.OKAY);
    }

    entity.setTopic(topic);
    entity.setUser(user);

    super.create(entity);

    return new Subscription_check(topic,
        Subscription_check.Result.OKAY);
    
  }

    @POST
    @Path("delete")
    @Consumes({"application/xml", "application/json"})
    public Subscription_check check_to_delete(Subscriber entity) {

      Query queryTopic = em.createQuery(
          "SELECT t FROM Topic t WHERE t.name = :name");
      queryTopic.setParameter("name", entity.getTopic().getName());

      List<Topic> topics = queryTopic.getResultList();

      if (topics.isEmpty()) {
        return new Subscription_check(entity.getTopic(),
            Subscription_check.Result.NO_TOPIC);
      }

      Topic topic = topics.get(0);

      Query queryUser = em.createQuery(
          "SELECT u FROM User u WHERE u.login = :login");
      queryUser.setParameter("login", entity.getUser().getLogin());

      List<User> users = queryUser.getResultList();

      if (users.isEmpty()) {
        return new Subscription_check(topic,
            Subscription_check.Result.NO_SUBSCRIPTION);
      }

      User user = users.get(0);

      Query querySubscription = em.createQuery(
          "SELECT s FROM Subscriber s WHERE s.topic = :topic AND s.user = :user");
      querySubscription.setParameter("topic", topic);
      querySubscription.setParameter("user", user);

      List<Subscriber> subscriptions = querySubscription.getResultList();

      if (subscriptions.isEmpty()) {
        return new Subscription_check(topic,
            Subscription_check.Result.NO_SUBSCRIPTION);
      }

      Subscriber subscriber = subscriptions.get(0);

      em.remove(em.merge(subscriber));

      return new Subscription_check(topic,
          Subscription_check.Result.OKAY);
    }

  @POST
  @Path("subscriptions")
  @Consumes({"application/xml", "application/json"})
  @Produces({"application/xml", "application/json"})
  public List<Subscriber> subscriptions(User entity) {
    
    Query queryUser = em.createQuery(
      "SELECT u FROM User u WHERE u.login = :login");
    queryUser.setParameter("login", entity.getLogin());

    List<User> users = queryUser.getResultList();

    if (users.isEmpty()) {
      return new java.util.ArrayList<Subscriber>();
    }

    User user = users.get(0);

    Query query = em.createQuery(
        "SELECT s FROM Subscriber s WHERE s.user = :user");
    query.setParameter("user", user);

    return query.getResultList();
  }
  
    @POST
    @Path("followers")
    @Consumes({"application/xml", "application/json"})
    @Produces({"application/xml", "application/json"})
    public Followers_check followers(Topic entity) {

      Query queryTopic = em.createQuery(
          "SELECT t FROM Topic t WHERE t.name = :name");
      queryTopic.setParameter("name", entity.getName());

      List<Topic> topics = queryTopic.getResultList();

      if (topics.isEmpty()) {
        return new Followers_check(entity, 0);
      }

      Topic topic = topics.get(0);

      Query query = em.createQuery(
          "SELECT s FROM Subscriber s WHERE s.topic = :topic");
      query.setParameter("topic", topic);

      List<Subscriber> subscribers = query.getResultList();

      return new Followers_check(topic, subscribers.size());
    }

  @Override
  protected EntityManager getEntityManager() {
    return em;
  }

}
