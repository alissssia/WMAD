package apiREST;

import com.google.gson.Gson;
import entity.Subscriber;
import util.Subscription_check;
import entity.User;
import java.io.*;
import java.net.*;
import java.util.Arrays;
import java.util.List;
import entity.Topic;
import util.Followers_check;

public class apiREST_Subscriber {
  public static Subscription_check createSubscriber(Subscriber subscriber) {
    try {
      URL url = new URL(Cons.SERVER_REST+"/entity.subscriber/create");
      HttpURLConnection ucon = (HttpURLConnection) url.openConnection();

      ucon.setRequestMethod("POST");
      ucon.setDoInput(true);
      ucon.setDoOutput(true);
      ucon.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      ucon.setRequestProperty("Accept", "application/json; charset=utf-8");

      PrintWriter out = new PrintWriter(ucon.getOutputStream(), true);
      Gson gson = new Gson();
      String json = gson.toJson(subscriber);
      System.out.println(json);
      out.println(json);
      out.flush();
      ucon.connect();

      BufferedReader in = new BufferedReader(new InputStreamReader(ucon.getInputStream()));
      return gson.fromJson(in, Subscription_check.class);

    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

  public static Subscription_check deleteSubscriber(Subscriber subscriber) {
    try {
      URL url = new URL(Cons.SERVER_REST+"/entity.subscriber/delete");
      HttpURLConnection ucon = (HttpURLConnection) url.openConnection();

      ucon.setRequestMethod("POST");
      ucon.setDoInput(true);
      ucon.setDoOutput(true);
      ucon.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      ucon.setRequestProperty("Accept", "application/json; charset=utf-8");
      
      PrintWriter out = new PrintWriter(ucon.getOutputStream(), true);
      Gson gson = new Gson();
      String json = gson.toJson(subscriber);
      System.out.println(json);
      out.println(json);
      out.flush();
      ucon.connect();

      BufferedReader in = new BufferedReader(new InputStreamReader(ucon.getInputStream()));
      return gson.fromJson(in, Subscription_check.class);

    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
  
  public static List<Subscriber> mySubscriptions(User user) {
    try {
      URL url = new URL(Cons.SERVER_REST+"/entity.subscriber/subscriptions");
      HttpURLConnection ucon = (HttpURLConnection) url.openConnection();

      ucon.setRequestMethod("POST");
      ucon.setDoInput(true);
      ucon.setDoOutput(true);
      ucon.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      ucon.setRequestProperty("Accept", "application/json; charset=utf-8");

      PrintWriter out = new PrintWriter(ucon.getOutputStream(), true);
      Gson gson = new Gson();
      String json = gson.toJson(user);
      System.out.println(json);
      out.println(json);
      out.flush();
      ucon.connect();

      BufferedReader in = new BufferedReader(new InputStreamReader(ucon.getInputStream()));
      Subscriber[] subscriberArray = gson.fromJson(in, Subscriber[].class);
      return Arrays.asList(subscriberArray);

    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
  
  public static Integer followers(Topic topic) {
    try {
      URL url = new URL(Cons.SERVER_REST + "/entity.subscriber/followers");
        HttpURLConnection ucon = (HttpURLConnection) url.openConnection();

        ucon.setRequestMethod("POST");
        ucon.setDoInput(true);
        ucon.setDoOutput(true);
        ucon.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        ucon.setRequestProperty("Accept", "application/json; charset=utf-8");

        PrintWriter out = new PrintWriter(ucon.getOutputStream(), true);
        Gson gson = new Gson();
        String json = gson.toJson(topic);

        System.out.println(json);

        out.println(json);
        out.flush();
        ucon.connect();

        BufferedReader in =
            new BufferedReader(new InputStreamReader(ucon.getInputStream()));

        Followers_check result = gson.fromJson(in, Followers_check.class);

        if (result == null) {
          return 0;
        }

        return result.followers;

    } catch (Exception e) {
      e.printStackTrace();
      return 0;
    }
  }
}
