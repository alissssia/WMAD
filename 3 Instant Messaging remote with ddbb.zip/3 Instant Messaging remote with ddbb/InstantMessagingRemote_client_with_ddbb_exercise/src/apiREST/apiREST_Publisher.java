package apiREST;

import com.google.gson.Gson;
import entity.Publisher;
import entity.User;
import java.io.*;
import java.net.*;
import java.util.List;
import java.util.Arrays;

public class apiREST_Publisher {
  public static void createPublisher(Publisher publisher) {
    try {
      URL url = new URL(Cons.SERVER_REST+"/entity.publisher/create");
      HttpURLConnection ucon = (HttpURLConnection) url.openConnection();

      ucon.setRequestMethod("POST");
      ucon.setDoInput(true);
      ucon.setDoOutput(true);
      ucon.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      ucon.setRequestProperty("Accept", "application/json; charset=utf-8");

      PrintWriter out = new PrintWriter(ucon.getOutputStream(), true);
      String json = new Gson().toJson(publisher);
      System.out.println(json);
      out.println(json);
      out.flush();
      ucon.connect();

      BufferedReader in = new BufferedReader(new InputStreamReader(ucon.getInputStream()));
      String line;
      while ((line = in.readLine()) != null) {
        System.out.println(line);
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static void deletePublisher(Publisher publisher) {
    try {
      URL url = new URL(Cons.SERVER_REST+"/entity.publisher/delete");
      HttpURLConnection ucon = (HttpURLConnection) url.openConnection();

      ucon.setRequestMethod("POST");
      ucon.setDoInput(true);
      ucon.setDoOutput(true);
      ucon.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      ucon.setRequestProperty("Accept", "application/json; charset=utf-8");
      
      PrintWriter out = new PrintWriter(ucon.getOutputStream(), true);
      String json = new Gson().toJson(publisher);
      System.out.println(json);
      out.println(json);
      out.flush();
      ucon.connect();

      BufferedReader in = new BufferedReader(new InputStreamReader(ucon.getInputStream()));
      String line;
      while ((line = in.readLine()) != null) {
        System.out.println(line);
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  public static Publisher PublisherOf(User user) {
    try {
      URL url = new URL(Cons.SERVER_REST+"/entity.publisher/publisherOf");
      HttpURLConnection ucon = (HttpURLConnection) url.openConnection();

      ucon.setRequestMethod("POST");
      ucon.setDoInput(true);
      ucon.setDoOutput(true);
      ucon.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      ucon.setRequestProperty("Accept", "application/json; charset=utf-8");

      PrintWriter out = new PrintWriter(ucon.getOutputStream(), true);
      Gson gson = new Gson();
      String json = gson.toJson(user);
      System.out.println(json);
      out.println(json);
      out.flush();
      ucon.connect();

      BufferedReader in = new BufferedReader(new InputStreamReader(ucon.getInputStream()));
      return gson.fromJson(in, Publisher.class);

    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
  
  public static List<Publisher> PublishersOf(User user) {
    try {
      URL url = new URL(Cons.SERVER_REST + "/entity.publisher/publishersOf");
      HttpURLConnection ucon = (HttpURLConnection) url.openConnection();

      ucon.setRequestMethod("POST");
      ucon.setDoInput(true);
      ucon.setDoOutput(true);
      ucon.setRequestProperty("Content-Type", "application/json; charset=utf-8");
      ucon.setRequestProperty("Accept", "application/json; charset=utf-8");

      PrintWriter out = new PrintWriter(ucon.getOutputStream(), true);
      Gson gson = new Gson();
      String json = gson.toJson(user);

      System.out.println(json);

      out.println(json);
      out.flush();
      ucon.connect();

      BufferedReader in =
          new BufferedReader(new InputStreamReader(ucon.getInputStream()));

      Publisher[] publishers = gson.fromJson(in, Publisher[].class);

      if (publishers == null) {
        return new java.util.ArrayList<Publisher>();
      }

      return Arrays.asList(publishers);

    } catch (Exception e) {
      e.printStackTrace();
      return new java.util.ArrayList<Publisher>();
    }
  }
}
