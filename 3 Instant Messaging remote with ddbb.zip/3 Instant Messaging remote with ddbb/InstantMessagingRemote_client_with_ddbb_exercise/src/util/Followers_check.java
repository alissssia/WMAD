/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import entity.Topic;

/**
 *
 * @author entel
 */
public class Followers_check {
    public Topic topic;
    public int followers;

    public Followers_check(Topic topic, int followers) {
      this.topic = topic;
      this.followers = followers;
    }

    public Followers_check() {
    }
}
