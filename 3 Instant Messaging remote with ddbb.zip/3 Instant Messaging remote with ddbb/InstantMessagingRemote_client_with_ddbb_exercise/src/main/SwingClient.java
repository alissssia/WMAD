package main;

import entity.Message;
import util.Subscription_check;
import entity.Topic;
import subscriber.SubscriberImpl;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import publisher.Publisher;
import subscriber.Subscriber;
import topicmanager.TopicManager;
import topicmanager.TopicManagerStub;
import webSocketService.WebSocketClient;

public class SwingClient {

  TopicManager topicManager;
  public Map<Topic, Subscriber> my_subscriptions;
  public Map<Topic, Publisher> my_publishers;

  JFrame frame;
  JTextArea topic_list_TextArea;
  public JTextArea messages_TextArea;
  public JTextArea my_subscriptions_TextArea;
  JTextArea publisher_TextArea;
  JTextField argument_TextField;

  public SwingClient(TopicManager topicManager) {
    this.topicManager = topicManager;
    my_subscriptions = new HashMap<Topic, Subscriber>();
    my_publishers = new HashMap<Topic, Publisher>();
  }

  public void createAndShowGUI() {

    String login = ((TopicManagerStub) topicManager).user.getLogin();
    frame = new JFrame("Publisher/Subscriber demo, user : " + login);
    frame.setSize(300, 300);
    frame.addWindowListener(new CloseWindowHandler());

    topic_list_TextArea = new JTextArea(5, 10);
    messages_TextArea = new JTextArea(10, 20);
    my_subscriptions_TextArea = new JTextArea(5, 10);
    publisher_TextArea = new JTextArea(1, 10);
    argument_TextField = new JTextField(20);

    JButton show_topics_button = new JButton("show Topics");
    JButton new_publisher_button = new JButton("new Publisher");
    JButton no_longer_publisher_button = new JButton("no-longer-publisher");
    JButton new_subscriber_button = new JButton("new Subscriber");
    JButton to_unsubscribe_button = new JButton("to unsubscribe");
    JButton to_post_an_event_button = new JButton("post an event");
    JButton to_close_the_app = new JButton("close app.");

    show_topics_button.addActionListener(new showTopicsHandler());
    new_publisher_button.addActionListener(new newPublisherHandler());
    no_longer_publisher_button.addActionListener(new noLongerPublisherHandler());
    new_subscriber_button.addActionListener(new newSubscriberHandler());
    to_unsubscribe_button.addActionListener(new UnsubscribeHandler());
    to_post_an_event_button.addActionListener(new postEventHandler());
    to_close_the_app.addActionListener(new CloseAppHandler());

    JPanel buttonsPannel = new JPanel(new FlowLayout());
    buttonsPannel.add(show_topics_button);
    buttonsPannel.add(new_publisher_button);
    buttonsPannel.add(no_longer_publisher_button);
    buttonsPannel.add(new_subscriber_button);
    buttonsPannel.add(to_unsubscribe_button);
    buttonsPannel.add(to_post_an_event_button);
    buttonsPannel.add(to_close_the_app);

    JPanel argumentP = new JPanel(new FlowLayout());
    argumentP.add(new JLabel("Write topic for publisher/subscriber/unsubscribe/no-longer-publisher, or topic1,topic2: message to post:"));
    argumentP.add(argument_TextField);

    JPanel topicsP = new JPanel();
    topicsP.setLayout(new BoxLayout(topicsP, BoxLayout.PAGE_AXIS));
    topicsP.add(new JLabel("Topics:"));
    topicsP.add(topic_list_TextArea);
    topicsP.add(new JScrollPane(topic_list_TextArea));
    topicsP.add(new JLabel("My Subscriptions:"));
    topicsP.add(my_subscriptions_TextArea);
    topicsP.add(new JScrollPane(my_subscriptions_TextArea));
    topicsP.add(new JLabel("I'm Publisher of topic:"));
    topicsP.add(publisher_TextArea);
    topicsP.add(new JScrollPane(publisher_TextArea));

    JPanel messagesPanel = new JPanel();
    messagesPanel.setLayout(new BoxLayout(messagesPanel, BoxLayout.PAGE_AXIS));
    messagesPanel.add(new JLabel("Messages:"));
    messagesPanel.add(messages_TextArea);
    messagesPanel.add(new JScrollPane(messages_TextArea));

    Container mainPanel = frame.getContentPane();
    mainPanel.add(buttonsPannel, BorderLayout.PAGE_START);
    mainPanel.add(messagesPanel, BorderLayout.CENTER);
    mainPanel.add(argumentP, BorderLayout.PAGE_END);
    mainPanel.add(topicsP, BorderLayout.LINE_START);

    //this is where you restore the user profile:
    clientSetup();

    frame.pack();
    frame.setVisible(true);
  }

 private void clientSetup() {

    // show existent topics
    List<Topic> topics = topicManager.topics();
    topic_list_TextArea.setText("");

    for (Topic t : topics) {
        Integer followers = topicManager.followers(t);
        topic_list_TextArea.append(t.name + " - followers: " + followers + "\n");
    }

    // restore publisher
    List<entity.Publisher> publishers =
    ((TopicManagerStub) topicManager).publishersOf();

    publisher_TextArea.setText("");

    for (entity.Publisher p : publishers) {

      Topic topic = p.getTopic();
      Publisher publisher = new publisher.PublisherStub(topic);

      my_publishers.put(topic, publisher);

      publisher_TextArea.append(topic.name + "\n");
    }

    // restore subscriptions
    List<entity.Subscriber> subscriptions =
        ((TopicManagerStub) topicManager).mySubscriptions();

    my_subscriptions_TextArea.setText("");

    for (entity.Subscriber s : subscriptions) {

      Topic topic = s.getTopic();

      SubscriberImpl subscriber = new SubscriberImpl(this);

      my_subscriptions.put(topic, subscriber);
      WebSocketClient.addSubscriber(topic, subscriber);

      my_subscriptions_TextArea.append(topic.name + "\n");

      // restore messages
      List<Message> messages = topicManager.messagesFrom(topic);

      for (Message m : messages) {
        messages_TextArea.append(m.topic.name + ": " + m.content + "\n");
      }
    }
  }

  class showTopicsHandler implements ActionListener {

    public void actionPerformed(ActionEvent e) {
      
      List<Topic> topics = topicManager.topics();

        topic_list_TextArea.setText("");

        for (Topic t : topics) {
            Integer followers = topicManager.followers(t);
            topic_list_TextArea.append(t.getName() + " - followers: " + followers + "\n");
        }
    
    }
  }

  class newPublisherHandler implements ActionListener {

    public void actionPerformed(ActionEvent e) {

        String topicName = argument_TextField.getText();

        if (topicName == null || topicName.equals("")) {
          return;
        }

        Topic topic = new Topic(topicName);

        if (my_publishers.containsKey(topic)) {
          messages_TextArea.append("You are already publisher of topic: "
              + topic.name + "\n");
          return;
        }

        Publisher publisher = topicManager.addPublisherToTopic(topic);

        my_publishers.put(topic, publisher);

        publisher_TextArea.append(topic.name + "\n");

        argument_TextField.setText("");
      }
  }
  
  class noLongerPublisherHandler implements ActionListener {

    public void actionPerformed(ActionEvent e) {

        String topicName = argument_TextField.getText();

        if (topicName == null || topicName.equals("")) {
          messages_TextArea.append("Write the topic you no longer want to publish\n");
          return;
        }

        Topic topic = new Topic(topicName);

        if (!my_publishers.containsKey(topic)) {
          messages_TextArea.append("You are not publisher of topic: "
              + topic.name + "\n");
          return;
        }

        topicManager.removePublisherFromTopic(topic);

        my_publishers.remove(topic);

        publisher_TextArea.setText("");

        for (Topic t : my_publishers.keySet()) {
          publisher_TextArea.append(t.name + "\n");
        }

        messages_TextArea.append("You are no longer publisher of topic: "
            + topic.name + "\n");

        argument_TextField.setText("");
      }
  }

  class newSubscriberHandler implements ActionListener {

    public void actionPerformed(ActionEvent e) {

      String topicName = argument_TextField.getText();

      if (topicName == null || topicName.equals("")) {
        return;
      }

      Topic topic = new Topic(topicName);
      SubscriberImpl subscriber = new SubscriberImpl(SwingClient.this);

      Subscription_check result = topicManager.subscribe(topic, subscriber);

      if (result.result == Subscription_check.Result.OKAY) {
        my_subscriptions.put(topic, subscriber);
        my_subscriptions_TextArea.append(topic.name + "\n");
      } else {
        messages_TextArea.append("Could not subscribe to topic: "
            + topic.name + "\n");
      }

      argument_TextField.setText("");
    }
  }

  class UnsubscribeHandler implements ActionListener {

    public void actionPerformed(ActionEvent e) {

      String topicName = argument_TextField.getText();

      if (topicName == null || topicName.equals("")) {
        return;
      }

      Topic topic = new Topic(topicName);

      Subscriber subscriber = my_subscriptions.get(topic);

      if (subscriber == null) {
        messages_TextArea.append("You are not subscribed to topic: "
            + topic.name + "\n");
        return;
      }

      Subscription_check result = topicManager.unsubscribe(topic, subscriber);

      if (result.result == Subscription_check.Result.OKAY) {
        my_subscriptions.remove(topic);

        my_subscriptions_TextArea.setText("");

        for (Topic t : my_subscriptions.keySet()) {
          my_subscriptions_TextArea.append(t.name + "\n");
        }
      } else {
        messages_TextArea.append("Could not unsubscribe from topic: "
            + topic.name + "\n");
      }

      argument_TextField.setText("");
    }
  }

  class postEventHandler implements ActionListener {

    public void actionPerformed(ActionEvent e) {

        String text = argument_TextField.getText();

        if (text == null || text.equals("")) {
          return;
        }

        if (!text.contains(":")) {
          messages_TextArea.append("Use format topic1,topic2: message\n");
          return;
        }

        String[] parts = text.split(":", 2);

        String topicsPart = parts[0].trim();
        String content = parts[1].trim();

        if (topicsPart.equals("") || content.equals("")) {
          messages_TextArea.append("Use format topic1,topic2: message\n");
          return;
        }

        String[] topicNames = topicsPart.split(",");

        boolean atLeastOnePublished = false;

        for (String topicName : topicNames) {

          topicName = topicName.trim();

          if (topicName.equals("")) {
            continue;
          }

          Topic topic = new Topic(topicName);

          Publisher publisher = my_publishers.get(topic);

          if (publisher == null) {
            messages_TextArea.append("You are not publisher of topic: "
                + topic.name + "\n");
            continue;
          }

          Message message = new Message(topic, content);

          publisher.publish(message);

          messages_TextArea.append("Message sent to topic: "
              + topic.name + "\n");

          atLeastOnePublished = true;
        }

        if (!atLeastOnePublished) {
          messages_TextArea.append("Message was not sent to any topic\n");
        }

        argument_TextField.setText("");
      }
  }

  class CloseAppHandler implements ActionListener {

    public void actionPerformed(ActionEvent e) {
        
      topicManager.close();

      System.out.println("one user closed");
      System.exit(0);
    }
  }

  class CloseWindowHandler implements WindowListener {

    public void windowDeactivated(WindowEvent e) {
    }

    public void windowActivated(WindowEvent e) {
    }

    public void windowIconified(WindowEvent e) {
    }

    public void windowDeiconified(WindowEvent e) {
    }

    public void windowClosed(WindowEvent e) {
    }

    public void windowOpened(WindowEvent e) {
    }

    public void windowClosing(WindowEvent e) {
      
      topicManager.close();
    
      System.out.println("one user closed");
      System.exit(0);
    }
  }
}
