package edu.upc.whatsapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import edu.upc.whatsapp.R;
import entity.Message;
import entity.UserInfo;
import android.widget.ImageView;

/**
 *
 * @author juanluis
 */
public class MyAdapter_messages extends BaseAdapter {

  private Context mContext;
  private List<Message> messages;
  private List<Integer> date_visibility;
  private UserInfo my_user;
  private String last_date_shown;

  public MyAdapter_messages(Context context, List<Message> messages, UserInfo user) {
    mContext = context;
    this.messages = messages;
    my_user = user;
    last_date_shown = "none";
    date_visibility = new ArrayList<Integer>();
    for (Message message : messages) {
      set_date_visibility(message);
    }
  }

  public void addMessage(Message new_message){
    messages.add(new_message);
    set_date_visibility(new_message);
  }
  public void addMessages(List<Message> new_messages){
    for(Message new_message : new_messages){
      messages.add(new_message);
      set_date_visibility(new_message);
    }
  }
  public boolean isEmpty(){
    return messages.isEmpty();
  }
  public Message getLastMessage(){
    return messages.get(messages.size() - 1);
  }

  public int getCount() {
    return messages.size();
  }

  public View getView(int position, View convertView, ViewGroup parent) {

    if (convertView == null) {
      if (getItemViewType(position) == 0) {
        convertView = LayoutInflater.from(mContext).inflate(R.layout.row_whatsapp_right_bubble, parent, false);
      }
      if (getItemViewType(position) == 1) {
        convertView = LayoutInflater.from(mContext).inflate(R.layout.row_whatsapp_left_bubble, parent, false);
      }
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy MMM dd");
    SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm");
    Date date = messages.get(position).getDate();
    if(date_visibility.get(position)==View.VISIBLE)
      convertView.findViewById(R.id.row_date).setVisibility(View.VISIBLE);
    else
      convertView.findViewById(R.id.row_date).setVisibility(View.GONE);
    ((TextView) convertView.findViewById(R.id.row_date)).setText(sdf.format(date));

    ((TextView) convertView.findViewById(R.id.row_content)).setText(messages.get(position).getContent());

    ((TextView) convertView.findViewById(R.id.row_hour)).setText(sdf2.format(date));

    if (getItemViewType(position) == 0) {

      ImageView oneCheck = (ImageView) convertView.findViewById(R.id.row_one_check);
      ImageView twoChecksGrey = (ImageView) convertView.findViewById(R.id.row_two_checks_grey);
      ImageView twoChecksBlue = (ImageView) convertView.findViewById(R.id.row_two_checks_blue);

      oneCheck.setVisibility(View.GONE);
      twoChecksGrey.setVisibility(View.GONE);
      twoChecksBlue.setVisibility(View.GONE);

      String status = messages.get(position).getStatus();

      if (status == null || status.equals("sent")) {
        oneCheck.setVisibility(View.VISIBLE);
      }
      else if (status.equals("delivered")) {
        twoChecksGrey.setVisibility(View.VISIBLE);
      }
      else if (status.equals("read")) {
        twoChecksBlue.setVisibility(View.VISIBLE);
      }
    }

    return convertView;
  }

  public Object getItem(int arg0) {
    return messages.get(arg0);
  }

  public long getItemId(int arg0) {
    return messages.get(arg0).getId();
  }

  @Override
  public int getItemViewType(int position) {

    Message message = messages.get(position);

    if(message.getUserSender().getId() == my_user.getId()){
      return 0;
    }
    else{
      return 1;
    }
  }

  @Override
  public int getViewTypeCount() {
    return 2; // Count of different layouts
  }

  @Override
  public boolean isEnabled(int position) {
    return true;
  }

  private void set_date_visibility(Message message) {
    Date date = message.getDate();
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    String day_of_year = calendar.get(Calendar.DAY_OF_YEAR)+"-"+calendar.get(Calendar.YEAR);
    if (last_date_shown.equals("none")) {
      last_date_shown = day_of_year;
      date_visibility.add(View.VISIBLE);
    } else if (!last_date_shown.equals(day_of_year)) {
      last_date_shown = day_of_year;
      date_visibility.add(View.VISIBLE);
    } else {
      date_visibility.add(View.GONE);
    }
  }

  public void removeMessage(Message message) {
    messages.remove(message);
  }

}
